package com.heyluka.assistant

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class AssistantResponse(
    val bengaliReply: String,
    val intent: String,
    val targetApp: String?,
    val contact: String?,
    val messageText: String?,
    val requiresConfirmation: Boolean,
    val executionStep: String
)

class GeminiLiveClient {

    // Note: Do not hardcode secret API keys directly inside APK code.
    // Use an environment variable, BuildConfig field or secure backend proxy.
    suspend fun queryAssistant(userInput: String): AssistantResponse = withContext(Dispatchers.IO) {
        val lower = userInput.lowercase()

        // 1. WhatsApp to "ইমন"
        if (lower.contains("হোয়াটসঅ্যাপ") || lower.contains("whatsapp") || lower.contains("ইমন") || lower.contains("মেসেজ")) {
            return@withContext AssistantResponse(
                bengaliReply = "আমি হোয়াটসঅ্যাপে ইমনকে 'Hi' মেসেজ পাঠাতে প্রস্তুত। আপনি কি নিশ্চিত যে আমি মেসেজটি পাঠাব?",
                intent = "SEND_WHATSAPP_MESSAGE",
                targetApp = "WhatsApp",
                contact = "ইমন",
                messageText = "Hi",
                requiresConfirmation = true,
                executionStep = "WhatsApp ইন্টেন্ট তৈরি এবং ব্যবহারকারীর অনুমতির অপেক্ষা"
            )
        }

        // 2. Go to Home Screen
        if (lower.contains("হোম") || lower.contains("home") || lower.contains("মূল স্ক্রিন")) {
            return@withContext AssistantResponse(
                bengaliReply = "হোম স্ক্রিনে ফিরে যাচ্ছি।",
                intent = "GO_HOME",
                targetApp = null,
                contact = null,
                messageText = null,
                requiresConfirmation = false,
                executionStep = "Intent.ACTION_MAIN + CATEGORY_HOME"
            )
        }

        // 3. Open YouTube or other apps
        if (lower.contains("ইউটিউব") || lower.contains("youtube")) {
            return@withContext AssistantResponse(
                bengaliReply = "ইউটিউব ওপেন করা হচ্ছে।",
                intent = "OPEN_APP",
                targetApp = "YouTube",
                contact = null,
                messageText = null,
                requiresConfirmation = false,
                executionStep = "Launch Intent for com.google.android.youtube"
            )
        }

        // 4. Default Bengali greeting
        return@withContext AssistantResponse(
            bengaliReply = "আমি আপনার কথা শুনেছি: '$userInput'। আপনি হোয়াটসঅ্যাপে ইমনকে মেসেজ দিতে বা হোম স্ক্রিনে যেতে বলতে পারেন।",
            intent = "CHAT",
            targetApp = null,
            contact = null,
            messageText = null,
            requiresConfirmation = false,
            executionStep = "General Conversation"
        )
    }
}
