package com.heyluka.assistant

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.Locale

data class LukaUiState(
    val isListening: Boolean = false,
    val isSpeaking: Boolean = false,
    val userTranscript: String = "",
    val assistantReplyBn: String = "স্বাগতম! আমি হে লুকা।",
    val statusMessageBn: String = "প্রস্তুত",
    val isAwaitingConfirmation: Boolean = false,
    val pendingContact: String? = null,
    val pendingMessageText: String? = null
)

class VoiceSessionManager(
    private val context: Context,
    private val automationDispatcher: AndroidAutomationDispatcher
) : TextToSpeech.OnInitListener {

    private val _uiState = MutableStateFlow(LukaUiState())
    val uiState: StateFlow<LukaUiState> = _uiState.asStateFlow()

    private var speechRecognizer: SpeechRecognizer? = null
    private var textToSpeech: TextToSpeech? = null
    private val geminiClient = GeminiLiveClient()
    private val scope = CoroutineScope(Dispatchers.Main)

    init {
        textToSpeech = TextToSpeech(context, this)
        initSpeechRecognizer()
    }

    private fun initSpeechRecognizer() {
        if (SpeechRecognizer.isRecognitionAvailable(context)) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {
                        _uiState.value = _uiState.value.copy(
                            isListening = true,
                            statusMessageBn = "শুনছি... কথা বলুন"
                        )
                    }

                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rmsdB: Float) {}
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() {
                        _uiState.value = _uiState.value.copy(
                            isListening = false,
                            statusMessageBn = "বিশ্লেষণ করা হচ্ছে..."
                        )
                    }

                    override fun onError(error: Int) {
                        _uiState.value = _uiState.value.copy(
                            isListening = false,
                            statusMessageBn = "ত্রুটি ঘটেছে (কোড: $error)। আবার চেষ্টা করুন।"
                        )
                    }

                    override fun onResults(results: Bundle?) {
                        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        val text = matches?.firstOrNull() ?: ""
                        if (text.isNotEmpty()) {
                            processUserVoiceInput(text)
                        }
                    }

                    override fun onPartialResults(partialResults: Bundle?) {}
                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
            }
        }
    }

    fun startPushToTalk() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "bn-BD")
            putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, false)
        }
        speechRecognizer?.startListening(intent)
    }

    fun stopListening() {
        speechRecognizer?.stopListening()
        _uiState.value = _uiState.value.copy(isListening = false)
    }

    private fun processUserVoiceInput(userInput: String) {
        _uiState.value = _uiState.value.copy(userTranscript = userInput)

        scope.launch {
            val response = geminiClient.queryAssistant(userInput)
            speakOut(response.bengaliReply)

            if (response.requiresConfirmation) {
                _uiState.value = _uiState.value.copy(
                    assistantReplyBn = response.bengaliReply,
                    isAwaitingConfirmation = true,
                    pendingContact = response.contact,
                    pendingMessageText = response.messageText,
                    statusMessageBn = "ব্যবহারকারীর অনুমোদনের অপেক্ষা"
                )
            } else {
                _uiState.value = _uiState.value.copy(
                    assistantReplyBn = response.bengaliReply,
                    isAwaitingConfirmation = false,
                    statusMessageBn = "কাজ সম্পন্ন হয়েছে"
                )
                // Execute immediately if no sensitive confirmation needed
                executeIntentAction(response)
            }
        }
    }

    fun confirmPendingAction() {
        val contact = _uiState.value.pendingContact ?: "ইমন"
        val message = _uiState.value.pendingMessageText ?: "Hi"

        _uiState.value = _uiState.value.copy(
            isAwaitingConfirmation = false,
            statusMessageBn = "মেসেজ পাঠানো হচ্ছে..."
        )

        // 1. WhatsApp ওপেন এবং মেসেজ সেন্ড
        val success = automationDispatcher.sendWhatsAppMessage(contact, message)
        if (success) {
            speakOut("ইমনকে মেসেজ পাঠানো হয়েছে এবং হোম স্ক্রিনে ফিরে আসা হচ্ছে।")
            // 2. হোম স্ক্রিনে ফিরে যাওয়া
            automationDispatcher.goToHomeScreen()
            _uiState.value = _uiState.value.copy(statusMessageBn = "সফলভাবে পাঠানো হয়েছে")
        } else {
            speakOut("মেসেজ পাঠাতে সমস্যা হয়েছে। অ্যাক্সেসিবিলিটি সার্ভিস চালু আছে কিনা পরীক্ষা করুন।")
            _uiState.value = _uiState.value.copy(statusMessageBn = "ব্যর্থ হয়েছে")
        }
    }

    fun cancelPendingAction() {
        _uiState.value = _uiState.value.copy(
            isAwaitingConfirmation = false,
            statusMessageBn = "অ্যাকশন বাতিল করা হয়েছে"
        )
        speakOut("অ্যাকশনটি বাতিল করা হলো।")
    }

    private fun executeIntentAction(response: AssistantResponse) {
        when (response.intent) {
            "GO_HOME" -> automationDispatcher.goToHomeScreen()
            "OPEN_APP" -> response.targetApp?.let { automationDispatcher.openApp(it) }
            else -> {}
        }
    }

    private fun speakOut(text: String) {
        _uiState.value = _uiState.value.copy(isSpeaking = true)
        textToSpeech?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "LukaTTS")
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = textToSpeech?.setLanguage(Locale("bn", "BD"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                textToSpeech?.setLanguage(Locale.US)
            }
        }
    }

    fun destroy() {
        speechRecognizer?.destroy()
        textToSpeech?.stop()
        textToSpeech?.shutdown()
    }
}
