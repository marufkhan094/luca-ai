package com.heyluka.assistant

import android.content.Context
import android.util.Log

/**
 * WakeWordDetector - হে লুকা অন-ডিভাইস ওয়েক-ওয়ার্ড ডিটেকশন আর্কিটেকচার
 * 
 * গুরুত্বপূর্ণ নোটিশ:
 * Gemini Live API কখনই সার্বক্ষণিক ওয়েক-ওয়ার্ড মনিটরিং প্রদান করে না।
 * ফোনের ব্যাটারি ও ডেটা বাঁচাতে অন-ডিভাইস লাইব্রেরি (যেমন Picovoice Porcupine অথবা Vosk)
 * ব্যবহার করে শুধুমাত্র "হে লুকা" বা "Hey Luka" শোনা মাত্রই মূল অ্যাসিস্ট্যান্ট সক্রিয় হয়।
 */
class WakeWordDetector(private val context: Context, private val onWakeWordDetected: () -> Unit) {

    private var isRunning = false

    fun startListening() {
        if (isRunning) return
        isRunning = true
        Log.d("WakeWord", "ওয়েক-ওয়ার্ড লিসেনিং শুরু: 'হে লুকা' শব্দটির জন্য অপেক্ষা...")
        // Vosk / Porcupine audio buffer loop executes here
    }

    fun stopListening() {
        isRunning = false
        Log.d("WakeWord", "ওয়েক-ওয়ার্ড লিসেনিং বন্ধ করা হয়েছে")
    }

    // Call when audio buffer matches "hey_luka" model
    private fun triggerWakeEvent() {
        onWakeWordDetected.invoke()
    }
}
