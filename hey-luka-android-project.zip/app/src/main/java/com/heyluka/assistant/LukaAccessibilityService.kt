package com.heyluka.assistant

import android.accessibilityservice.AccessibilityService
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class LukaAccessibilityService : AccessibilityService() {

    companion object {
        var instance: LukaAccessibilityService? = null
            private set

        var isPendingWhatsAppSend = false
        var targetMessageText: String? = null
        var targetContactName: String? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.packageName != "com.whatsapp") return

        // If an automated action is pending and confirmed
        if (isPendingWhatsAppSend) {
            val rootNode = rootInActiveWindow ?: return
            handleWhatsAppAutomation(rootNode)
        }
    }

    private fun handleWhatsAppAutomation(rootNode: AccessibilityNodeInfo) {
        try {
            // 1. Find message input field
            val editTexts = rootNode.findAccessibilityNodeInfosByViewId("com.whatsapp:id/entry")
            if (editTexts.isNotEmpty()) {
                val inputNode = editTexts[0]
                val args = Bundle().apply {
                    putCharSequence(
                        AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
                        targetMessageText ?: "Hi"
                    )
                }
                inputNode.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)

                // 2. Click WhatsApp Send Button
                val sendButtons = rootNode.findAccessibilityNodeInfosByViewId("com.whatsapp:id/send")
                if (sendButtons.isNotEmpty()) {
                    sendButtons[0].performAction(AccessibilityNodeInfo.ACTION_CLICK)
                    isPendingWhatsAppSend = false
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun performGlobalHome() {
        performGlobalAction(GLOBAL_ACTION_HOME)
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        super.onDestroy()
        instance = null
    }
}
