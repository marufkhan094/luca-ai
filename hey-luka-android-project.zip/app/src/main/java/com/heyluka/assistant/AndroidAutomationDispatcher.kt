package com.heyluka.assistant

import android.content.Context
import android.content.Intent
import android.net.Uri

class AndroidAutomationDispatcher(private val context: Context) {

    // 1. হোম স্ক্রিনে ফিরে যাওয়া (Return to Android Home screen)
    fun goToHomeScreen(): Boolean {
        return try {
            val homeIntent = Intent(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_HOME)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(homeIntent)
            true
        } catch (e: Exception) {
            // Alternatively use Accessibility Service Global Action
            LukaAccessibilityService.instance?.performGlobalHome() ?: false
        }
    }

    // 2. হোয়াটসঅ্যাপ মেসেজিং অ্যাকশন (User-confirmed workflow)
    fun sendWhatsAppMessage(contactName: String, message: String): Boolean {
        return try {
            // Setup target variables in Accessibility Service for safe execution
            LukaAccessibilityService.targetContactName = contactName
            LukaAccessibilityService.targetMessageText = message
            LukaAccessibilityService.isPendingWhatsAppSend = true

            // Open WhatsApp directly via intent
            val intent = context.packageManager.getLaunchIntentForPackage("com.whatsapp")
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
                true
            } else {
                // If WhatsApp is not installed
                false
            }
        } catch (e: Exception) {
            false
        }
    }

    // 3. অন্যান্য অ্যাপ ওপেন করা (Open installed apps)
    fun openApp(appName: String): Boolean {
        return try {
            val packageName = when (appName.lowercase()) {
                "youtube", "ইউটিউব" -> "com.google.android.youtube"
                "chrome", "ক্রোম" -> "com.android.chrome"
                "settings", "সেটিংস" -> "com.android.settings"
                else -> null
            }

            if (packageName != null) {
                val intent = context.packageManager.getLaunchIntentForPackage(packageName)
                if (intent != null) {
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(intent)
                    return true
                }
            }
            false
        } catch (e: Exception) {
            false
        }
    }
}
